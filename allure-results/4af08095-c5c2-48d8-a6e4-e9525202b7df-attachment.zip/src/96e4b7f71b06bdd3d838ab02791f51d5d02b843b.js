
export class DashboardPage {
    constructor(page) { 
        this.page = page;
        this.menuIcon = page.getByAltText("menu"); // Note: Corrected getAltText to getByAltText
        this.signOutButton = page.getByText("Sign out", { exact: true });
    }

    async clickOnMenuIcon() {
        await this.menuIcon.click();
    }

    async clickOnSignOutButton() {
        // FIXED: Changed from this.clickOnSignOutButton.click() to this.signOutButton.click()
        await this.signOutButton.click(); 
    }
}
